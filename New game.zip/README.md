# Huddersfield Hustle

Installable browser/PWA prototype for a fictional, choice-driven crime drama.

## Run

Open `index.html` for the quickest preview. For install/offline support, serve this folder from a local web server:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080` and choose **Install app** in the browser menu.

## Included

- Smartphone-style app hub
- Typed messages plus context-style quick replies
- Cash, reputation, heat and chapter progression
- Relationships, marketplace, transport, property, social feed, banking and map
- Local save data via `localStorage`
- Offline PWA cache

All risky activity is abstracted into fictional story choices; the prototype does not provide real-world criminal instructions.
